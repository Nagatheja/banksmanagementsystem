export class Bank {
    id:number=0;
    ifsc_code: string = "";
    bankName: string = "";
    manager: string = "";
    city: string = "";
    pincode:number=0;
}